#!/bin/bash
# RegisLex CLI
cd "$(dirname "$0")"
./bin/regislex-cli "$@"
