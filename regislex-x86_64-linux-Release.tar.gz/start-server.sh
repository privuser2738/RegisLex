#!/bin/bash
# RegisLex Server Launcher
cd "$(dirname "$0")"
./bin/regislex "$@"
